<?php  
// A void filled with echoes.